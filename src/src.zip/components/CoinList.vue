<template>
  <section class="list-container">
    <div class="exchange-tabs">
      <button :class="{ active: activeTab === 'UPBIT' }" @click="selectExchangeTab('UPBIT')">Upbit</button>
      <button :class="{ active: activeTab === 'BINANCE' }" @click="selectExchangeTab('BINANCE')">Binance</button>
      <button :class="{ active: activeTab === 'FAVORITES' }" @click="activeTab = 'FAVORITES'">관심목록</button>
    </div>

    <div class="list-header">
      <span class="col-name">종목</span>
      <span>현재가</span>
      <span>전일대비</span>
      <span>거래대금</span>
    </div>

    <div class="list-body">
      <p v-if="activeTab === 'FAVORITES' && displayedTickers.length === 0" class="empty-favorites">
        관심목록에 추가된 코인이 없습니다.
      </p>
      <CoinListItem
        v-for="coin in displayedTickers"
        :key="coin.market_code"
        :coin="coin"
        :selected="coin.market_code === selectedMarketCode"
        :is-favorite="favorites.includes(coin.market_code)"
        @select="$emit('select-coin', coin.market_code)"
        @toggle-fav="toggleFavorite"
      />
    </div>
  </section>
</template>

<script setup>
import Cookies from 'js-cookie'
import { computed, onMounted, ref } from 'vue'
import CoinListItem from './CoinListItem.vue'

const props = defineProps({
  exchange: { type: String, required: true },
  tickers: { type: Array, default: () => [] },
  allTickers: { type: Array, default: () => [] },
  selectedMarketCode: { type: String, default: '' },
})

const emit = defineEmits(['select-coin', 'update:exchange'])

const favorites = ref([])
const activeTab = ref(props.exchange)

onMounted(() => {
  try {
    favorites.value = JSON.parse(Cookies.get('mock_favorites') || '[]')
  } catch {
    favorites.value = []
  }
})

const displayedTickers = computed(() => {
  if (activeTab.value === 'FAVORITES') {
    return props.allTickers.filter((coin) => favorites.value.includes(coin.market_code))
  }
  return props.tickers
})

const selectExchangeTab = (exchange) => {
  activeTab.value = exchange
  emit('update:exchange', exchange)
}

const toggleFavorite = (marketCode) => {
  const index = favorites.value.indexOf(marketCode)
  if (index === -1) favorites.value.push(marketCode)
  else favorites.value.splice(index, 1)
  Cookies.set('mock_favorites', JSON.stringify(favorites.value), { expires: 30 })
}
</script>
